<?php include 'inc/header.php'; ?>

<section class="banner" style="display: none;">
    <div class="bannerimg">
        <img class="init-one" src="images/banner-grid.jpg" alt="Dark Grid Overlay">
        <img class="init-zero" src="images/banner-grid-icons.png" alt="Geometric Icons Grid">
    </div>

    <div class="container">
        <div class="banner-row">
            <div class="banner-left">
                <!-- <div class="left-text"> -->
                <!-- Verification Badge -->
                <div class="verification">
                    <div class="verification-icon"><img src="images/badge-check.png" alt=""> Verified</div>
                    <span class="verification-text">Trusted by Businesses</span>
                </div>

                <!-- Main Heading -->
                <h1 class="heading">
                    Crafting
                    <div class="highlight-wrapper" id="highlightWrapper">
                        <span class="highlight-text">Digital Experiences</span>
                        <div class="selection-container-1">
                            <div class="custom-cursor-1"></div>
                            <div class="selection-box-1">
                                <div class="sq sq1"></div>
                                <div class="sq sq2"></div>
                                <div class="sq sq3"></div>
                                <div class="sq sq4"></div>
                            </div>
                        </div>
                    </div>
                    <br>
                    That Inspire <span class="text-highlight-1" id="textHighlight1">Growth</span>
                    <span class="text-highlight-2" id="textHighlight2">And</span>
                    Innovation

                    <!-- Second Selection Area -->
                    <div class="selection-area-2">
                        <div class="custom-cursor-2"></div>

                    </div>

                    <!-- Third Selection Area - New Complex Path -->
                    <div class="selection-area-3">
                        <div class="custom-cursor-3"></div>

                    </div>
                </h1>

                <!-- Description -->
                <p class="description">
                    From web to mobile to cloud, we design solutions that redefine businesses.
                </p>

                <!-- Buttons -->
                <div class="button-container">
                    <a href="#!" class="btn has-icon">Get Started <span><img src="images/arrow-long-right.png" alt=""></span></a>
                    <a href="#!" class="btn btn-black">View Our Work</a>
                </div>
            </div>
            <div class="banner-right">
                <div class="logoarea">
                    <ul>
                        <li>
                            <div class="bn-logo"><img src="images/banner-logo-google.png" alt=""></div>
                            <div class="bn-text"><span>4.2</span><img src="images/banner-staricon.png" alt=""></div>
                        </li>

                        <li>
                            <div class="bn-logo"><img src="images/banner-logo-clutch.png" alt=""></div>
                            <div class="bn-text"><span>4.2</span><img src="images/banner-staricon.png" alt=""></div>
                        </li>

                        <li>
                            <div class="bn-logo"><img src="images/banner-logo-goodfirms.png" alt=""></div>
                            <div class="bn-text"><span>4.2</span><img src="images/banner-staricon.png" alt=""></div>
                        </li>

                        <li>
                            <div class="bn-logo"><img src="images/banner-logo-trustpilot.png" alt=""></div>
                            <div class="bn-text"><span>4.2</span><img src="images/banner-staricon.png" alt=""></div>
                        </li>
                    </ul>
                </div>

                <div class="trust-widget">
                    <div class="trust-widget-inner">
                        <div class="avatar-stack">
                            <img src="images/trustedby-1.png" alt="User 1" class="avatar">
                            <img src="images/trustedby-2.png" alt="User 2" class="avatar">
                            <img src="images/trustedby-3.png" alt="User 3" class="avatar">
                            <img src="images/trustedby-4.png" alt="User 4" class="avatar">
                        </div>
                        <div class="rating-block">
                            <div class="stars">
                                <span class="star"><img src="images/trustedby-star.png" alt=""></span>
                                <span class="star"><img src="images/trustedby-star.png" alt=""></span>
                                <span class="star"><img src="images/trustedby-star.png" alt=""></span>
                                <span class="star"><img src="images/trustedby-star.png" alt=""></span>
                                <span class="star"><img src="images/trustedby-star.png" alt=""></span>
                            </div>
                            <div class="score">4.9</div>
                        </div>
                    </div>
                    <p class="trust-text">Trusted by 50+ companies worldwide</p>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="splide logo-slider" aria-label="Trusted Companies">
    <div class="splide__track">
        <ul class="splide__list">
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-1.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-2.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-3.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-4.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-5.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-1.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-2.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-3.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-4.png" alt="">
                </div>
            </li>
            <li class="splide__slide">
                <div class="splide__slide__container">
                    <img src="images/trusted-companies-5.png" alt="">
                </div>
            </li>
        </ul>
    </div>
</section>

<section class="ideas">
    <div class="container">
        <div class="subheading">
            <h6>Innovation. Design. Engineering.</h6>
            <div class="sq sq1"></div>
            <div class="sq sq2"></div>
            <div class="sq sq3"></div>
            <div class="sq sq4"></div>
        </div>
        <div class="mxw-853">
            <h2>From <span>Ideas</span> to <span>Impactful Technology</span></h2>
            <p>Build Smarter Digital Solutions with Fortmindz – Kolkata’s trusted software development partner. From web and mobile apps to cloud and custom solutions, we craft technology that grows your business. Let’s turn your idea into reality today.</p>
            <a href="#!" class="btn btn-black">Let’s Get Started</a>
        </div>
        <div class="stats">
            <ul>
                <li>
                    <div class="icon">
                        <img src="images/stats-1-icon.png" alt="">
                    </div>
                    <div class="text">
                        <h6>14+</h6>
                        <span>Years of Expertise</span>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <img src="images/stats-1-icon.png" alt="">
                    </div>
                    <div class="text">
                        <h6>4+</h6>
                        <span>Awards in Last 1 Year</span>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <img src="images/stats-3-icon.png" alt="">
                    </div>
                    <div class="text">
                        <h6>100+</h6>
                        <span>In-house Experts</span>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <img src="images/stats-4-icon.png" alt="">
                    </div>
                    <div class="text">
                        <h6>850+</h6>
                        <span>Successful Projects</span>
                    </div>
                </li>
                <li>
                    <div class="icon">
                        <img src="images/stats-5-icon.png" alt="">
                    </div>
                    <div class="text">
                        <h6>450+</h6>
                        <span>Satisfied Clients</span>
                    </div>
                </li>
            </ul>
        </div>
    </div>
</section>

<section class="our-services pt-0" style="display: none;">
    <div class="container">
        <div class="servlogoarea">
            <img src="images/services-logo.png" alt="">
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="spacing">

                </div>
            </div>
            <div class="col-md-9">
                <div class="serv-right">
                    <div class="subheading">
                        <h6>Our Services</h6>
                        <div class="sq sq1"></div>
                        <div class="sq sq2"></div>
                        <div class="sq sq3"></div>
                        <div class="sq sq4"></div>
                    </div>
                    <h2>Comprehensive Digital Solutions for Every Stage</h2>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col-md-3">
                <div class="serv-left">
                    <ul>
                        <li class="active">
                            Digital Products
                        </li>
                        <li>
                            Design & Experience
                        </li>
                        <li>
                            Engineering & Development
                        </li>
                        <li>
                            Quality & Growth
                        </li>
                    </ul>
                </div>
            </div>
            <div class="col-md-9">
                <div class="serv-scroll-slide">
                    <div class="slide-inner">
                        <h4>Digital Products</h4>
                        <div class="slide-row">
                            <div class="slidebx">
                                <div class="icon">
                                    <img src="images/digi-prod-1.png" alt="">
                                </div>
                                <h5>Mobile App<br> Development</h5>
                                <p>Create engaging mobile experiences for iOS & Android with seamless performance.</p>
                            </div>

                            <div class="slidebx">
                                <div class="icon">
                                    <img src="images/digi-prod-2.png" alt="">
                                </div>
                                <h5>Web<br> Development</h5>
                                <p>Build responsive, scalable websites tailored to your business needs and designed for growth.</p>
                            </div>

                            <div class="slidebx">
                                <div class="icon">
                                    <img src="images/digi-prod-3.png" alt="">
                                </div>
                                <h5>E-Commerce<br> Solutions</h5>
                                <p>Develop secure, conversion-driven online stores that scale with your brand.</p>
                            </div>
                        </div>
                        <!-- Buttons -->
                        <div class="button-container">
                            <a href="#!" class="btn has-icon">Explore More <span><img src="images/arrow-long-right.png" alt=""></span></a>
                            <a href="#!" class="btn btn-white">Talk to Our Expert</a>
                        </div>
                    </div>

                    <div class="slide-inner">
                        <h4>Design & Experience</h4>
                        <div class="slide-row two-slide">
                            <div class="slidebx">
                                <div class="icon">
                                    <img src="images/digi-prod-1.png" alt="">
                                </div>
                                <h5>UI/UX Design</h5>
                                <p>Design intuitive interfaces that delight users and boost engagement.</p>
                            </div>

                            <div class="slidebx ">
                                <div class="icon">
                                    <img src="images/digi-prod-2.png" alt="">
                                </div>
                                <h5>Logo & Graphic Design</h5>
                                <p>Build strong brand identities with impactful visuals and consistent storytelling.</p>
                            </div>
                        </div>
                        <!-- Buttons -->
                        <div class="button-container">
                            <a href="#!" class="btn has-icon">Get Started <span><img src="images/arrow-long-right.png" alt=""></span></a>
                            <a href="#!" class="btn btn-black">View Our Work</a>
                        </div>
                    </div>

                    <div class="slide-inner">
                        <h4>Engineering & Development</h4>
                        <div class="slide-row">
                            <div class="slidebx">
                                <div class="icon">
                                    <img src="images/engine-prod-1.png" alt="">
                                </div>
                                <h5>Full Stack<br> Development</h5>
                                <p>End-to-end engineering solutions with modern frameworks for speed and security.</p>
                            </div>

                            <div class="slidebx">
                                <div class="icon">
                                    <img src="images/engine-prod-2.png" alt="">
                                </div>
                                <h5>Custom Software<br> Development</h5>
                                <p>Tailored software that meets your unique business challenges.</p>
                            </div>

                            <div class="slidebx">
                                <div class="icon">
                                    <img src="images/engine-prod-3.png" alt="">
                                </div>
                                <h5>Cloud<br> Engineering</h5>
                                <p>Leverage cloud-native solutions for scalability, security, and efficiency.</p>
                            </div>
                        </div>
                        <!-- Buttons -->
                        <div class="button-container">
                            <a href="#!" class="btn has-icon">Get Started <span><img src="images/arrow-long-right.png" alt=""></span></a>
                            <a href="#!" class="btn btn-black">View Our Work</a>
                        </div>
                    </div>

                    <div class="slide-inner">
                        <h4>Quality & Growth</h4>
                        <div class="slide-row two-slide">
                            <div class="slidebx">
                                <div class="icon">
                                    <img src="images/quality-prod-1.png" alt="">
                                </div>
                                <h5>QA & Testing</h5>
                                <p>Ensure flawless performance with manual and automated testing.</p>
                            </div>

                            <div class="slidebx ">
                                <div class="icon">
                                    <img src="images/quality-prod-2.png" alt="">
                                </div>
                                <h5>Digital Marketing</h5>
                                <p>Boost visibility and conversions with data-driven campaigns.</p>
                            </div>
                        </div>
                        <!-- Buttons -->
                        <div class="button-container">
                            <a href="#!" class="btn has-icon">Get Started <span><img src="images/arrow-long-right.png" alt=""></span></a>
                            <a href="#!" class="btn btn-black">View Our Work</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<section class="industry" style="background: #f4f4f4 url(images/banner-grid.png) repeat-y 0 0; background-size: contain;">
    <div class="container">
        <div class="subheading">
            <h6>Industry</h6>
            <div class="sq sq1"></div>
            <div class="sq sq2"></div>
            <div class="sq sq3"></div>
            <div class="sq sq4"></div>
        </div>
        <h2>Let’s work together <span>anywhere around the world</span></h2>
        <p>Business isn't one size fits all. Every industry requires a custom solution. Learn more about how we've helped businesses in your industry by clicking below.</p>
        <div class="grid-container">
            <!-- First Row -->
            <div class="grid-row">
                <!-- Box 1 -->
                <div class="box" tabindex="0" role="button" aria-expanded="false">
                    <div class="box-inner">
                        <div class="box-main">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="48" viewBox="0 0 60 48" fill="none">
                                <path class="fillblack" d="M58.2895 5.42412H14.6336C14.3312 5.42412 14.0734 5.20331 14.0294 4.9055C13.7953 3.31085 13.1764 2.23163 12.472 1.50175C11.5277 0.523067 10.2045 0 8.84231 0H2.08888C0.935337 0 0 0.932867 0 2.08336C0 3.23385 0.935337 4.16672 2.08888 4.16672H7.94271C9.59007 4.16672 9.88739 5.42475 9.88739 5.42475C9.88739 5.42475 14.5468 24.9246 15.2774 28.5695C16.0085 32.2144 15.2774 30.7566 14.5462 34.5835C14.4907 34.8731 14.4569 35.146 14.4416 35.4038C14.3146 37.5342 16.036 39.3223 18.1759 39.3223H21.0253C19.8405 40.1992 19.073 41.6042 19.073 43.1887C19.073 45.846 21.2327 48.0006 23.8977 48.0006C26.562 48.0006 28.7224 45.8466 28.7224 43.1887C28.7224 41.6042 27.9542 40.1992 26.77 39.3223H41.2658C40.081 40.1992 39.3135 41.6042 39.3135 43.1887C39.3135 45.846 41.4732 48.0006 44.1382 48.0006C46.8026 48.0006 48.9629 45.8466 48.9629 43.1887C48.9629 41.6042 48.1947 40.1992 47.0106 39.3223H50.2721C51.4327 39.3223 52.3738 38.3837 52.3738 37.2262C52.3738 36.0687 51.4327 35.1301 50.2721 35.1301H19.2063L20.5768 31.8498H47.9867C50.6996 31.8498 53.0928 30.0795 53.8808 27.4903L59.9254 7.62393C60.2584 6.52879 59.4366 5.42412 58.2895 5.42412Z" fill="#FC9611" />
                                <path d="M17.1799 16.8999L17.7682 19.6609H42.8321L38.678 23.8493C38.1446 24.387 38.1465 25.2537 38.6831 25.7888C39.2203 26.3246 40.0906 26.3259 40.6297 25.792L47.6537 18.8349C48.0122 18.4799 48.0135 17.9014 47.6556 17.5451L40.8345 10.7414C40.3349 10.2432 39.5349 10.2126 38.9983 10.6708C38.4005 11.1818 38.3654 12.093 38.9224 12.6479L43.185 16.8992H17.1799V16.8999Z" fill="white" />
                            </svg>
                            <h3 class="box-title">Home</h3>
                        </div>
                        <div class="box-content">
                            <button class="close-btn" aria-label="Close"><i class="fas fa-times"></i></button>
                            <p>Tailored e-commerce UI/UX solutions in Kolkata that optimize product discovery
                                and checkout flows.</p>
                        </div>
                    </div>
                </div>

                <!-- Box 2 -->
                <div class="box" tabindex="0" role="button" aria-expanded="false">
                    <div class="box-inner">
                        <div class="box-main">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="48" viewBox="0 0 60 48" fill="none">
                                <path class="fillblack" d="M58.2895 5.42412H14.6336C14.3312 5.42412 14.0734 5.20331 14.0294 4.9055C13.7953 3.31085 13.1764 2.23163 12.472 1.50175C11.5277 0.523067 10.2045 0 8.84231 0H2.08888C0.935337 0 0 0.932867 0 2.08336C0 3.23385 0.935337 4.16672 2.08888 4.16672H7.94271C9.59007 4.16672 9.88739 5.42475 9.88739 5.42475C9.88739 5.42475 14.5468 24.9246 15.2774 28.5695C16.0085 32.2144 15.2774 30.7566 14.5462 34.5835C14.4907 34.8731 14.4569 35.146 14.4416 35.4038C14.3146 37.5342 16.036 39.3223 18.1759 39.3223H21.0253C19.8405 40.1992 19.073 41.6042 19.073 43.1887C19.073 45.846 21.2327 48.0006 23.8977 48.0006C26.562 48.0006 28.7224 45.8466 28.7224 43.1887C28.7224 41.6042 27.9542 40.1992 26.77 39.3223H41.2658C40.081 40.1992 39.3135 41.6042 39.3135 43.1887C39.3135 45.846 41.4732 48.0006 44.1382 48.0006C46.8026 48.0006 48.9629 45.8466 48.9629 43.1887C48.9629 41.6042 48.1947 40.1992 47.0106 39.3223H50.2721C51.4327 39.3223 52.3738 38.3837 52.3738 37.2262C52.3738 36.0687 51.4327 35.1301 50.2721 35.1301H19.2063L20.5768 31.8498H47.9867C50.6996 31.8498 53.0928 30.0795 53.8808 27.4903L59.9254 7.62393C60.2584 6.52879 59.4366 5.42412 58.2895 5.42412Z" fill="#FC9611" />
                                <path d="M17.1799 16.8999L17.7682 19.6609H42.8321L38.678 23.8493C38.1446 24.387 38.1465 25.2537 38.6831 25.7888C39.2203 26.3246 40.0906 26.3259 40.6297 25.792L47.6537 18.8349C48.0122 18.4799 48.0135 17.9014 47.6556 17.5451L40.8345 10.7414C40.3349 10.2432 39.5349 10.2126 38.9983 10.6708C38.4005 11.1818 38.3654 12.093 38.9224 12.6479L43.185 16.8992H17.1799V16.8999Z" fill="white" />
                            </svg>
                            <h3 class="box-title">Profile</h3>
                        </div>
                        <div class="box-content">
                            <button class="close-btn" aria-label="Close"><i class="fas fa-times"></i></button>
                            <p>Manage your personal information and preferences here. Update your profile, change your password, and customize your experience to suit your needs.</p>
                        </div>
                    </div>
                </div>

                <!-- Box 3 -->
                <div class="box" tabindex="0" role="button" aria-expanded="false">
                    <div class="box-inner">
                        <div class="box-main">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="48" viewBox="0 0 60 48" fill="none">
                                <path class="fillblack" d="M58.2895 5.42412H14.6336C14.3312 5.42412 14.0734 5.20331 14.0294 4.9055C13.7953 3.31085 13.1764 2.23163 12.472 1.50175C11.5277 0.523067 10.2045 0 8.84231 0H2.08888C0.935337 0 0 0.932867 0 2.08336C0 3.23385 0.935337 4.16672 2.08888 4.16672H7.94271C9.59007 4.16672 9.88739 5.42475 9.88739 5.42475C9.88739 5.42475 14.5468 24.9246 15.2774 28.5695C16.0085 32.2144 15.2774 30.7566 14.5462 34.5835C14.4907 34.8731 14.4569 35.146 14.4416 35.4038C14.3146 37.5342 16.036 39.3223 18.1759 39.3223H21.0253C19.8405 40.1992 19.073 41.6042 19.073 43.1887C19.073 45.846 21.2327 48.0006 23.8977 48.0006C26.562 48.0006 28.7224 45.8466 28.7224 43.1887C28.7224 41.6042 27.9542 40.1992 26.77 39.3223H41.2658C40.081 40.1992 39.3135 41.6042 39.3135 43.1887C39.3135 45.846 41.4732 48.0006 44.1382 48.0006C46.8026 48.0006 48.9629 45.8466 48.9629 43.1887C48.9629 41.6042 48.1947 40.1992 47.0106 39.3223H50.2721C51.4327 39.3223 52.3738 38.3837 52.3738 37.2262C52.3738 36.0687 51.4327 35.1301 50.2721 35.1301H19.2063L20.5768 31.8498H47.9867C50.6996 31.8498 53.0928 30.0795 53.8808 27.4903L59.9254 7.62393C60.2584 6.52879 59.4366 5.42412 58.2895 5.42412Z" fill="#FC9611" />
                                <path d="M17.1799 16.8999L17.7682 19.6609H42.8321L38.678 23.8493C38.1446 24.387 38.1465 25.2537 38.6831 25.7888C39.2203 26.3246 40.0906 26.3259 40.6297 25.792L47.6537 18.8349C48.0122 18.4799 48.0135 17.9014 47.6556 17.5451L40.8345 10.7414C40.3349 10.2432 39.5349 10.2126 38.9983 10.6708C38.4005 11.1818 38.3654 12.093 38.9224 12.6479L43.185 16.8992H17.1799V16.8999Z" fill="white" />
                            </svg>
                            <h3 class="box-title">Settings</h3>
                        </div>
                        <div class="box-content">
                            <button class="close-btn" aria-label="Close"><i class="fas fa-times"></i></button>
                            <p>Configure your application settings to optimize your experience. Adjust notifications, privacy settings, and other preferences to make the platform work for you.</p>
                        </div>
                    </div>
                </div>

                <!-- Box 4 -->
                <div class="box" tabindex="0" role="button" aria-expanded="false">
                    <div class="box-inner">
                        <div class="box-main">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="48" viewBox="0 0 60 48" fill="none">
                                <path class="fillblack" d="M58.2895 5.42412H14.6336C14.3312 5.42412 14.0734 5.20331 14.0294 4.9055C13.7953 3.31085 13.1764 2.23163 12.472 1.50175C11.5277 0.523067 10.2045 0 8.84231 0H2.08888C0.935337 0 0 0.932867 0 2.08336C0 3.23385 0.935337 4.16672 2.08888 4.16672H7.94271C9.59007 4.16672 9.88739 5.42475 9.88739 5.42475C9.88739 5.42475 14.5468 24.9246 15.2774 28.5695C16.0085 32.2144 15.2774 30.7566 14.5462 34.5835C14.4907 34.8731 14.4569 35.146 14.4416 35.4038C14.3146 37.5342 16.036 39.3223 18.1759 39.3223H21.0253C19.8405 40.1992 19.073 41.6042 19.073 43.1887C19.073 45.846 21.2327 48.0006 23.8977 48.0006C26.562 48.0006 28.7224 45.8466 28.7224 43.1887C28.7224 41.6042 27.9542 40.1992 26.77 39.3223H41.2658C40.081 40.1992 39.3135 41.6042 39.3135 43.1887C39.3135 45.846 41.4732 48.0006 44.1382 48.0006C46.8026 48.0006 48.9629 45.8466 48.9629 43.1887C48.9629 41.6042 48.1947 40.1992 47.0106 39.3223H50.2721C51.4327 39.3223 52.3738 38.3837 52.3738 37.2262C52.3738 36.0687 51.4327 35.1301 50.2721 35.1301H19.2063L20.5768 31.8498H47.9867C50.6996 31.8498 53.0928 30.0795 53.8808 27.4903L59.9254 7.62393C60.2584 6.52879 59.4366 5.42412 58.2895 5.42412Z" fill="#FC9611" />
                                <path d="M17.1799 16.8999L17.7682 19.6609H42.8321L38.678 23.8493C38.1446 24.387 38.1465 25.2537 38.6831 25.7888C39.2203 26.3246 40.0906 26.3259 40.6297 25.792L47.6537 18.8349C48.0122 18.4799 48.0135 17.9014 47.6556 17.5451L40.8345 10.7414C40.3349 10.2432 39.5349 10.2126 38.9983 10.6708C38.4005 11.1818 38.3654 12.093 38.9224 12.6479L43.185 16.8992H17.1799V16.8999Z" fill="white" />
                            </svg>
                            <h3 class="box-title">Messages</h3>
                        </div>
                        <div class="box-content">
                            <button class="close-btn" aria-label="Close"><i class="fas fa-times"></i></button>
                            <p>Stay connected with your network through our messaging system. Send and receive messages, share files, and collaborate with your contacts in real-time.</p>
                        </div>
                    </div>
                </div>
            </div>

            <!-- Second Row -->
            <div class="grid-row">
                <!-- Box 5 -->
                <div class="box" tabindex="0" role="button" aria-expanded="false">
                    <div class="box-inner">
                        <div class="box-main">
                            <svg xmlns="http://www.w3.org/2000/svg" width="60" height="48" viewBox="0 0 60 48" fill="none">
                                <path class="fillblack" d="M58.2895 5.42412H14.6336C14.3312 5.42412 14.0734 5.20331 14.0294 4.9055C13.7953 3.31085 13.1764 2.23163 12.472 1.50175C11.5277 0.523067 10.2045 0 8.84231 0H2.08888C0.935337 0 0 0.932867 0 2.08336C0 3.23385 0.935337 4.16672 2.08888 4.16672H7.94271C9.59007 4.16672 9.88739 5.42475 9.88739 5.42475C9.88739 5.42475 14.5468 24.9246 15.2774 28.5695C16.0085 32.2144 15.2774 30.7566 14.5462 34.5835C14.4907 34.8731 14.4569 35.146 14.4416 35.4038C14.3146 37.5342 16.036 39.3223 18.1759 39.3223H21.0253C19.8405 40.1992 19.073 41.6042 19.073 43.1887C19.073 45.846 21.2327 48.0006 23.8977 48.0006C26.562 48.0006 28.7224 45.8466 28.7224 43.1887C28.7224 41.6042 27.9542 40.1992 26.77 39.3223H41.2658C40.081 40.1992 39.3135 41.6042 39.3135 43.1887C39.3135 45.846 41.4732 48.0006 44.1382 48.0006C46.8026 48.0006 48.9629 45.8466 48.9629 43.1887C48.9629 41.6042 48.1947 40.1992 47.0106 39.3223H50.2721C51.4327 39.3223 52.3738 38.3837 52.3738 37.2262C52.3738 36.0687 51.4327 35.1301 50.2721 35.1301H19.2063L20.5768 31.8498H47.9867C50.6996 31.8498 53.0928 30.0795 53.8808 27.4903L59.9254 7.62393C60.2584 6.52879 59.4366 5.42412 58.2895 5.42412Z" fill="#FC9611" />
                                <path d="M17.1799 16.8999L17.7682 19.6609H42.8321L38.678 23.8493C38.1446 24.387 38.1465 25.2537 38.6831 25.7888C39.2203 26.3246 40.0906 26.3259 40.6297 25.792L47.6537 18.8349C48.0122 18.4799 48.0135 17.9014 47.6556 17.5451L40.8345 10.7414C40.3349 10.2432 39.5349 10.2126 38.9983 10.6708C38.4005 11.1818 38.3654 12.093 38.9224 12.6479L43.185 16.8992H17.1799V16.8999Z" fill="white" />
                            </svg>
                            <h3 class="box-title">Analytics</h3>
                        </div>
                        <div class="box-content">
                            <button class="close-btn" aria-label="Close"><i class="fas fa-times"></i></button>
                            <p>Track your performance with our comprehensive analytics dashboard. Monitor key metrics, visualize data trends, and gain insights to make informed decisions.</p>
                        </div>
                    </div>
                </div>

                <!-- Box 6 -->
                <div class="box" tabindex="0" role="button" aria-expanded="false">
                    <div class="box-inner">
                        <div class="box-main">
                            <i class="fas fa-calendar box-icon"></i>
                            <h3 class="box-title">Calendar</h3>
                        </div>
                        <div class="box-content">
                            <button class="close-btn" aria-label="Close"><i class="fas fa-times"></i></button>
                            <p>Organize your schedule with our intuitive calendar feature. Create events, set reminders, and sync with other calendar applications to stay on top of your commitments.</p>
                        </div>
                    </div>
                </div>

                <!-- Box 7 -->
                <div class="box" tabindex="0" role="button" aria-expanded="false">
                    <div class="box-inner">
                        <div class="box-main">
                            <i class="fas fa-folder box-icon"></i>
                            <h3 class="box-title">Documents</h3>
                        </div>
                        <div class="box-content">
                            <button class="close-btn" aria-label="Close"><i class="fas fa-times"></i></button>
                            <p>Store and manage all your important documents in one secure location. Upload, organize, and share files with ease while maintaining control over access permissions.</p>
                        </div>
                    </div>
                </div>

                <!-- Box 8 -->
                <div class="box" tabindex="0" role="button" aria-expanded="false">
                    <div class="box-inner">
                        <div class="box-main">
                            <i class="fas fa-question-circle box-icon"></i>
                            <h3 class="box-title">Help</h3>
                        </div>
                        <div class="box-content">
                            <button class="close-btn" aria-label="Close"><i class="fas fa-times"></i></button>
                            <p>Find answers to your questions in our comprehensive help center. Browse FAQs, access tutorials, and contact our support team for personalized assistance.</p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php include 'inc/footer.php'; ?>